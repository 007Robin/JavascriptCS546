const recipesInfo = require("./recipes");
module.exports = {
    recipes: recipesInfo
}