const dbConnection = require("../config/mongoConnection");
const data = require("../data/");
const recipes = data.recipes;

const main = async () => {
    const db = await dbConnection();
    await db.dropDatabase();
    
    const recipe1 = await recipes.addRecipes("Fried Eggs", [
    {
        name: "Egg",
        amount: "2 eggs"
    }, 
    {
        name: "Olive Oil",
        amount: "2 tbsp"
    },], 
    ["First, heat a non-stick pan on medium-high until hot",
    "Add the oil to the pan and allow oil to warm; it is ready the oil immediately sizzles upon contact with a drop of water.",
    "Crack the egg and place the egg and yolk in a small prep bowl; do not crack the yolk!",
    "Gently pour the egg from the bowl onto the oil",    
    "Wait for egg white to turn bubbly and completely opaque (approx 2 min)",
    "Using a spatula, flip the egg onto its uncooked side until it is completely cooked (approx 2 min)",
    "Remove from oil and plate",
    "Repeat for second egg"]);
   
    const recipe2 = await recipes.addRecipes("Cheesy Chicken Broccoli Casserole",[
        {
            name: "olive oil",
            amount: "1 tbsp."
        },
        {
            name: "white rice",
            amount: "1 c"
        },
        {
            name: "heavy cream",
            amount: "1 c"
        },
        {
            name: "shredded Cheddar",
            amount: "1 c"
        }],
        ["In a large skillet over medium-high heat, heat oil. Add onion and garlic and cook until fragrant, about 5 minutes. Add chicken and season with salt and pepper. Cook until golden, about 6 minutes more.", 
        "To the skillet, add rice. Pour in chicken broth and heavy cream and stir to combine. Bring to a simmer and let cook until rice is fully cooked, about 15 minutes. Add more broth if necessary. Mix in broccoli and cheddar and continue cooking until cheese is melted and broccoli is tender.", 
        "Sprinkle skillet evenly with panko bread crumbs and season with salt and pepper. Broil until golden and crispy, about 2 minutes."]
        );
    console.log("Done seeding database");
    await db.serverConfig.close();
};

main().catch(console.log);
