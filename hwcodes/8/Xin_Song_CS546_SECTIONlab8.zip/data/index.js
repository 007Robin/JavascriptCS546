const resultRoutes = require("./result");

module.exports = {
  result: resultRoutes
};